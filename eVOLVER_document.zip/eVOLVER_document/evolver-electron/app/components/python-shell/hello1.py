import sys

import time

while (1):
    print('Hello 1 from Python!')
    sys.stdout.flush()
    time.sleep(2)
