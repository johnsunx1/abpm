BOSTON UNIVERSITY EDF
eVOLVER System

P/N EV-485 Rev B
4 Layer FR-4
1 oz copper
Final thickness 0.063
Solder mask both sides (green)
Silkscreen legend top only (white)

Contact:  Chris Lawlor / 617-353-4117 / cjlawlor@bu.edu

RS485-F.Cu.gbr         Layer 1 (positive)
RS485-In1.Cu.gbr       Layer 2 (positive)
RS485-In2.Cu.gbr       Layer 3 (positive)
RS485-B.Cu.gbr         Layer 4 (positive)
RS485-F.Mask.gbr       Top solder mask
RS485-F.SilkS.gbr      Top silkscreen
RS485-B.Mask.gbr       Bottom solder mask
RS485.drl              NC drill
RS485-Dwgs.User.gbr    Fab drawing
RS485-all.pos          Component positions
RS485-F.Paste.gbr      Solder paste (top only)
